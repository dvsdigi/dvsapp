export { FeaturesView, AboutView, ContactView } from './InfoViews';
export { default as DemoView } from './DemoView';
